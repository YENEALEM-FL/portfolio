import React from 'react';
const Degrees = () => {
  return (
    <div><h3>Education</h3>
      <ul>
        <li>
          <b>Master of Science in Computer Science</b><br/>
          (In progress via distance education; expected completion December 23, 2023)<br/>
          <i>Maharishi International University, Fairfield, Iowa</i>
        </li>
        
        <li>
          <b>Master of Science in Computer Science</b><br/>
          HiLCoE College of Computer Science and Technology, Addis Ababa, Ethiopia
        </li>
        
        <li>
          <b>Bachelor of Science in Information Systems</b><br/>
          Addis Ababa University, Addis Ababa, Ethiopia
        </li>



      </ul></div>
  );
};
export default Degrees;